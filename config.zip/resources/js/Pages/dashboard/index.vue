<template>
    <AppLayout>
        <template #content>
           
        </template>
    </AppLayout>
</template>

<script>
import AppLayout from '@/Layouts/App.vue';
export default {
    components: {
        AppLayout
    },
}
</script>

<style lang="stylus" scoped>

</style>
